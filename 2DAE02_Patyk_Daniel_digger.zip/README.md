# SteelEngine
This Project is a Game Engine that we have to create in Programming 4 in the Howest University: DAE.

You Control the player with the DPad on the Controller, you can collect the Emeralds to get points.
And you can dig through the world.

I did not like the combination of States and Commands. The Command pattern is a bit to complex for this project and makes stuff more complicated.

GitRepo: https://github.com/SirPytan/SteelEngine
