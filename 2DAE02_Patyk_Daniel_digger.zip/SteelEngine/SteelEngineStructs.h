#pragma once
#include "Enums.h"

struct Input
{
	Direction direction = Direction::None;
	bool shootFireball = false;
};
