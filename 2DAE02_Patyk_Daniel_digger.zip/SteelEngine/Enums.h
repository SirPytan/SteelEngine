#pragma once

#ifndef ENUMS
#define ENUMS

enum class Event
{
	Nothing, GotEmeralds
};

enum class Direction
{
	None, Left, Right, Up, Down
};
#endif
