#include "SteelEnginePCH.h"
#include "Command.h"

Command::Command()
{
	m_Input = nullptr;
}
