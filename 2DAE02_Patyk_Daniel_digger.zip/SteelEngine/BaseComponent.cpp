#include "SteelEnginePCH.h"
#include "BaseComponent.h"

dae::BaseComponent::BaseComponent()
	: m_pGameObject{nullptr}
{
}
